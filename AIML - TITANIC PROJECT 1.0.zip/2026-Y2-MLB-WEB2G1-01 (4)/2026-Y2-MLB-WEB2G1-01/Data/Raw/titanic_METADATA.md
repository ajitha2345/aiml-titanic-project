# 📋 Dataset Metadata — Enhanced Titanic Passenger Survival Dataset (1912)

---

## 👥 Collaborators
| Role | Name |
|---|---|
| Dataset Creator | Independent Data Scientist |
| Domain Consultant | Historical ML Research |
| License Holder | Public (CC BY 4.0) |

---

## ✍️ Authors
**Primary Author**: Synthetic Dataset Generator  
**Contact**: Available via Kaggle Discussion tab  
**Affiliation**: Educational / Portfolio Project  
**Contribution**: Dataset design, survival logic engineering, feature schema, documentation  

---

## 🌍 Coverage

| Field | Detail |
|---|---|
| **Temporal Coverage** | April 10–15, 1912 (RMS Titanic voyage) |
| **Geographic Coverage** | Atlantic Ocean; ports of Southampton (UK), Cherbourg (France), Queenstown (Ireland) |
| **Subject Coverage** | Passenger demographics, socioeconomic status, survival outcomes |
| **Passenger Count** | 4,000 simulated passengers |
| **Columns** | 30 features + 1 target |
| **Language** | English |
| **Region** | International (10 nationalities) |

---

## 🔗 DOI Citation

> This is a synthetic dataset for educational use. No official DOI has been assigned. If used in academic work, reference as:

```
Author: Synthetic Data Project
Title: Enhanced Titanic Passenger Survival Dataset (1912)
Year: 2024
License: Creative Commons Attribution 4.0 (CC BY 4.0)
Format: CSV
Platform: Kaggle
```

---

## 🧭 Provenance

### Generation Methodology
This dataset was generated entirely through programmatic simulation using Python (NumPy, Pandas). No real passenger records were used. The generation pipeline follows these steps:

**Step 1 — Population Sampling**  
4,000 passengers were sampled with:
- Class distribution: 20% First, 25% Second, 55% Third (historically aligned)
- Age distribution: Infant 2%, Child 12%, Teen 10%, Adult 60%, Senior 16%
- Gender split: 65% Male, 35% Female (reflects historical Titanic demographics)

**Step 2 — Feature Assignment**  
Each feature was assigned using conditional probability distributions correlated with passenger class and demographic group:
- Fare drawn from class-appropriate uniform distributions with Gaussian noise
- Deck assigned based on class (First→A/B/C, Second→D/E, Third→F/G/T)
- Lifeboat access probability weighted by class and deck position
- Nationality drawn from 10 historically represented groups
- Education and Wealth co-determined by Pclass

**Step 3 — Survival Scoring**  
A logistic-sigmoid survival function was computed from 8 weighted risk factors:
- Lifeboat access quality (weight: 0.40)
- Gender (Female +0.30 / Male -0.10)
- Passenger class (+0.25 / +0.05 / -0.15)
- Crew assistance received (+0.15 / -0.05)
- Age group (Child +0.20, Infant +0.10, Senior -0.20)
- Health condition (Healthy 0, Disabled -0.25)
- Distance to lifeboat (penalty up to -0.30)
- Emergency response time (penalty up to -0.20)
- Gaussian noise (σ=0.10) added for realism

**Step 4 — Missing Value Injection**  
Realistic missingness introduced:
- Age: 8% MCAR
- Cabin and Deck: ~21% (historically only ~20% of Titanic cabins were recorded)
- Embarked: <1% (2 historical passengers)

**Step 5 — Calibration**  
Survival probabilities adjusted to achieve a realistic 31–35% overall survival rate, matching historical Titanic records.

### Intended Uses
- Binary classification model training and benchmarking
- Feature engineering practice (title extraction, interaction terms, binning)
- Exploratory data analysis (EDA) and statistical visualization
- Deep learning / neural network tutorials on tabular data
- Missing data imputation experiments
- Fairness / bias analysis (class, gender, nationality)

### Limitations
- Synthetic data: statistical patterns are realistic but not empirically validated
- `SurvivalProbability` column is derived from the same survival model — **must be excluded** from feature sets to prevent leakage
- `Name` column uses repeating first/last names from pools; no genealogical authenticity
- Actual Titanic evacuation was more chaotic and less structured than this model implies

---

## 📄 License

**Creative Commons Attribution 4.0 International (CC BY 4.0)**

You are free to:
- ✅ **Share** — copy and redistribute the material in any medium or format
- ✅ **Adapt** — remix, transform, and build upon the material for any purpose, even commercially

Under the following terms:
- 📌 **Attribution** — You must give appropriate credit, provide a link to the license, and indicate if changes were made.

Full license text: [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)

---

## 🔄 Expected Update Frequency

| Field | Value |
|---|---|
| **Update Frequency** | Static (Never — historical simulation) |
| **Last Updated** | 2024 |
| **Version** | 1.0 |
| **Changelog** | Initial release — 4,000 rows, 30 columns |

> This dataset represents a fixed historical simulation. No future updates are planned unless a v2.0 is released with additional engineered features or expanded passenger count.

---

## 📊 Data Quality Scorecard

| Dimension | Status | Notes |
|---|---|---|
| Completeness | ✅ Intentional | Realistic missingness in Age, Cabin, Deck, Embarked |
| Consistency | ✅ High | Wealth aligns with Class; Deck aligns with Lifeboat Access |
| Validity | ✅ High | No impossible ages, fares, or family sizes |
| Uniqueness | ✅ 100% | All PassengerIDs unique |
| Accuracy | ⚠️ Synthetic | Historically inspired but not empirically verified |
| Timeliness | ✅ N/A | Historical simulation; timeliness not applicable |

---

## 🏷️ Full Tag List (Kaggle)

```
titanic, survival-analysis, binary-classification, historical-data,
synthetic-data, feature-engineering, random-forest, xgboost,
logistic-regression, eda, visualization, maritime-history,
imbalanced-classification, demographics, social-class,
gender-analysis, missing-data, beginners, intermediate, kaggle-competition
```
