# 🚢 Enhanced Titanic Passenger Survival Dataset (1912)

> A rich historical simulation dataset with 30 features and 4,000 passengers — purpose-built for machine learning, analytics, and visualization.

---

## 📖 Overview

The sinking of the RMS Titanic on April 15, 1912 remains one of the deadliest peacetime maritime disasters in history. Of the estimated 2,224 passengers and crew aboard, more than 1,500 perished. The tragedy exposed sharp inequalities in survival chances across gender, class, age, and deck location.

This **enhanced synthetic dataset** simulates 4,000 Titanic-era passengers with historically plausible demographics, survival logic, and 30 richly engineered features — far exceeding the scope of the original Kaggle Titanic dataset.

---

## 📊 Dataset at a Glance

| Property | Value |
|---|---|
| Rows | 4,000 |
| Columns | 30 |
| Target | `Survived` (0 = No, 1 = Yes) |
| Survival Rate | ~31% |
| Task Type | Binary Classification (primary) |
| Missing Values | Age (~8%), Cabin (~21%), Deck (~21%), Embarked (<1%) |

---

## 🗂️ Full Column Dictionary

| # | Column | Type | Description | Example |
|---|---|---|---|---|
| 1 | `PassengerID` | int | Unique passenger identifier | 1 – 4000 |
| 2 | `Survived` | int | **TARGET**: 1 = Survived, 0 = Did not survive | 0, 1 |
| 3 | `Pclass` | int | Ticket class: 1 = First, 2 = Second, 3 = Third | 1, 2, 3 |
| 4 | `Name` | string | Passenger name with title | "Smith, Mr. James" |
| 5 | `Gender` | categorical | Male / Female | Male |
| 6 | `Age` | float | Age in years (8% missing) | 24.5 |
| 7 | `SibSp` | int | # siblings/spouses aboard | 0–5 |
| 8 | `Parch` | int | # parents/children aboard | 0–4 |
| 9 | `FamilySize` | int | SibSp + Parch + 1 | 1–10 |
| 10 | `TicketNumber` | string | Ticket number with prefix | "PC 123456" |
| 11 | `Fare` | float | Ticket price in USD (1912) | $7.25 |
| 12 | `Cabin` | string | Cabin number (21% missing) | "C85" |
| 13 | `Embarked` | categorical | Port: S=Southampton, C=Cherbourg, Q=Queenstown | S |
| 14 | `Nationality` | categorical | Passenger's country of origin | British |
| 15 | `Occupation` | categorical | Self-reported occupation | Engineer |
| 16 | `MaritalStatus` | categorical | Single / Married / Widowed / Divorced | Married |
| 17 | `TravelPurpose` | categorical | Leisure / Business / Immigration / etc. | Immigration |
| 18 | `HealthCondition` | categorical | Healthy / Minor Illness / Chronic Condition / Disabled | Healthy |
| 19 | `Deck` | categorical | Ship deck letter (21% missing) | C |
| 20 | `LifeboatAccess` | categorical | Proximity/quality of lifeboat access | Good |
| 21 | `BoardingGroup` | categorical | Boarding priority group A–E | B |
| 22 | `BaggageWeightKg` | float | Registered baggage weight in kilograms | 35.2 |
| 23 | `TravelCompanionType` | categorical | Alone / Spouse / Friend / Family / Family Group | Alone |
| 24 | `EducationLevel` | categorical | None / Primary / Secondary / College / University | Secondary |
| 25 | `WealthCategory` | categorical | Low / Middle / Upper-Middle / Wealthy / Elite | Wealthy |
| 26 | `DistanceToLifeboatM` | float | Estimated distance (meters) to nearest lifeboat | 48.3 |
| 27 | `CrewAssistanceReceived` | categorical | Whether passenger received crew evacuation help | Yes |
| 28 | `EmergencyResponseTimeMin` | float | Minutes until passenger reached evacuation area | 14.7 |
| 29 | `SurvivalProbability` | float | Model-derived survival probability score (0–1) | 0.6821 |
| 30 | `AgeGroup` | categorical | Infant / Child / Teen / Adult / Senior | Adult |

---

## 📐 Class & Distribution Summary

### Passenger Class
| Class | % of Passengers | Fare Range |
|---|---|---|
| First | 20% | $30–$550 |
| Second | 25% | $10–$120 |
| Third | 55% | $3–$50 |

### Age Groups
| Group | % | Age Range |
|---|---|---|
| Infant | 2% | 0–1 |
| Child | 12% | 2–12 |
| Teen | 10% | 13–19 |
| Adult | 60% | 20–59 |
| Senior | 16% | 60–85 |

---

## 🤖 Machine Learning Use Cases

### Classification
- **Binary**: Predict `Survived` (0/1) — primary task
- **Multi-class**: Predict `WealthCategory` or `LifeboatAccess` from other features
- Models: Logistic Regression, Random Forest, XGBoost, LightGBM, Neural Nets

### Regression
- Predict `Fare` from class, nationality, baggage, travel purpose
- Predict `EmergencyResponseTimeMin` from deck, class, boarding group
- Predict `DistanceToLifeboatM` from deck and lifeboat access

### Clustering
- Group passengers by socioeconomic profile (wealth, class, education, occupation)
- Identify survival archetypes via K-Means or DBSCAN

### Feature Engineering
- `IsAlone` = FamilySize == 1
- `FarePerPerson` = Fare / FamilySize
- `TitleExtracted` from Name
- `AgeClassInteraction` = Age × Pclass
- `SurvivalRiskIndex` = composite of distance, ERT, lifeboat access

---

## 🔬 Research Questions

1. How strongly does gender predict survival, controlling for passenger class?
2. Which deck had the highest survival rate, and why?
3. Does family size have a non-linear relationship with survival?
4. How much does crew assistance improve survival odds across classes?
5. Was there a significant survival difference between immigrant and leisure travelers?
6. What is the relationship between baggage weight and wealth category?
7. Which nationalities had the highest and lowest survival rates?
8. How does boarding group affect emergency response time?
9. Did health condition interact with class to affect survival outcomes?
10. What is the optimal distance threshold to a lifeboat for predicting survival?
11. Can we predict a passenger's wealth category from occupation + fare alone?
12. How does family configuration (alone vs. group) affect survival probability?
13. Is education level a significant predictor of survival after controlling for class?
14. Which ML model achieves the best F1-score on this dataset?
15. Do passengers who received crew assistance have proportionally shorter emergency response times?
16. Can clustering reveal "survivor archetypes" distinct from the Titanic's known demographics?
17. How does travel purpose correlate with nationality and survival?

---

## 🔧 Preprocessing Recommendations

1. **Missing Values**:
   - `Age`: Impute with median grouped by `Pclass` + `Gender`
   - `Cabin`/`Deck`: Create binary feature `HasCabin`, then impute with mode
   - `Embarked`: Impute with mode ('S')
2. **Encoding**:
   - Ordinal: `LifeboatAccess`, `WealthCategory`, `EducationLevel`, `AgeGroup`
   - One-hot: `Gender`, `Embarked`, `Nationality`, `Occupation`, `TravelPurpose`
3. **Scaling**: StandardScaler or MinMaxScaler for `Fare`, `Age`, `DistanceToLifeboatM`, `BaggageWeightKg`
4. **Feature extraction**: Extract title from `Name`; bin `Age` and `Fare`
5. **Drop**: `PassengerID`, `Name`, `TicketNumber`, `SurvivalProbability` (leakage risk)

---

## ⚠️ Limitations

- This is a **synthetic dataset** — it is historically inspired but not derived from real passenger records.
- Survival logic is intentional but simplified; real outcomes were influenced by factors not captured here.
- `SurvivalProbability` is a feature derived from the same model that generated `Survived` — exclude it to avoid data leakage in classification tasks.
- The dataset is not suitable for publishing historical research or claims about real individuals.

---

## 📜 Provenance Statement

This dataset was generated programmatically using a weighted, logistic-inspired survival scoring system grounded in historical Titanic research. All passenger records are entirely synthetic. Survival outcomes are correlated with class, gender, age, lifeboat access, crew assistance, and emergency response time — reflecting known patterns from historical accounts. Randomness is added at each stage to prevent perfect determinism and to simulate real-world noise.

**Intended uses**: Education, ML practice, Kaggle competitions, EDA demonstrations, feature engineering tutorials.

---

## 🏷️ Kaggle Metadata

| Field | Value |
|---|---|
| **Title** | Enhanced Titanic Passenger Survival Dataset (1912) |
| **Subtitle** | A rich historical simulation dataset for ML, analytics, and visualization |
| **Category** | History · Transportation · Machine Learning |
| **License** | CC BY 4.0 |
| **Language** | English |
| **Format** | CSV |
| **Rows** | 4,000 |
| **Columns** | 30 |

### Tags (20)
`titanic` · `survival-analysis` · `binary-classification` · `historical-data` · `synthetic-data` · `feature-engineering` · `random-forest` · `xgboost` · `logistic-regression` · `eda` · `visualization` · `maritime-history` · `imbalanced-classification` · `demographics` · `social-class` · `gender-analysis` · `missing-data` · `beginners` · `intermediate` · `kaggle-competition`

### SEO Keywords (50)
titanic dataset, titanic survival prediction, titanic machine learning, titanic kaggle, enhanced titanic, synthetic titanic data, passenger survival classification, historical ML dataset, titanic EDA, titanic feature engineering, binary classification dataset, survival probability, kaggle titanic challenge, titanic neural network, passenger class analysis, titanic gender survival, titanic age survival, first class titanic, third class titanic, titanic deck analysis, lifeboat access dataset, emergency response prediction, crew assistance survival, titanic immigration, historical passenger data, RMS Titanic 1912, titanic nationality analysis, titanic wealth, titanic occupation, titanic family survival, titanic education, titanic clustering, DBSCAN titanic, titanic logistic regression, titanic random forest, titanic XGBoost, titanic LightGBM, titanic deep learning, titanic data science, titanic data analysis, titanic visualization, titanic seaborn, titanic matplotlib, titanic pandas, titanic scikit-learn, kaggle beginner, kaggle intermediate, classification benchmark, imbalanced classes, survival rate analysis

---

## 📋 Citation

If you use this dataset in your work, please cite:

```
Enhanced Titanic Passenger Survival Dataset (1912).
Synthetic dataset generated for educational and ML research purposes.
License: CC BY 4.0
```
