# IT2011 - Progress Review I: Data Preprocessing and EDA

## Project Overview
This project applies data cleaning, preprocessing, and exploratory data analysis (EDA) techniques to the Titanic dataset (`titanic_enhanced.csv`).

## Group Members & Roles
| Name | IT Number | Assigned Technique |
|---|---|---|
| Member 1 Name | IT2xxxxxxx | Handling Missing Data |
| Member 2 Name | IT2xxxxxxx | Encoding Categorical Variables |
| Member 3 Name | IT2xxxxxxx | Outlier Removal (IQR) |
| Member 4 Name | IT2xxxxxxx | Normalization / Scaling |
| Member 5 Name | IT2xxxxxxx | Feature Engineering & Correlation EDA |

## How to Run the Code
1. Ensure Python and Pandas, NumPy, Scikit-Learn, Seaborn, and Matplotlib are installed.
2. Place raw data inside `data/raw/`.
3. Run the integrated pipeline notebook: `group_pipeline.ipynb`.
4. The processed output dataset will be generated automatically at `results/outputs/processed_titanic.csv`.